var script  = document.createElement('script')
script.className = 'ttLights'
script.type = 'text/javascript'
script.src  = 'https://raw.github.com/egeste/ttLights/master/build/tt.lights.min.js'
document.head.appendChild(script)
